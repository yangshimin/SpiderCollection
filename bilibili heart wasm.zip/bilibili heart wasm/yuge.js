const fs = require('fs');
let wasmfilename = 'bilibili.wasm';

window = {
    location: {
        host: "live.bilibili.com",
        hostname: "live.bilibili.com",
        href: "https://live.bilibili.com/",
        origin: "https://live.bilibili.com",
        pathname: "/blanc/",
        protocol: "https:"
    }
};

document = {
    body: {
        childNodes: [0]
    }
};

var tmp;
var id_to_ref_map = {};
var last_refid = 1;

var __fun = function(){};

var importObject = {
    env: {
        __cargo_web_snippet_0d39c013e2144171d64e2fac849140a7e54c939a: function(r, t) {
            t = to_js(t);
            from_js(r, t.location)
        },
        __cargo_web_snippet_0f503de1d61309643e0e13a7871406891e3691c9: function(r) {
            from_js(r, window)
        },
        __cargo_web_snippet_10f5aa3985855124ab83b21d4e9f7297eb496508: function(r) {
            return id_to_ref_map[r] instanceof Array | 0;
        },
        __cargo_web_snippet_2b0b92aee0d0de6a955f8e5540d7923636d951ae: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.origin,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_461d4581925d5b0bf583a3b445ed676af8701ca6: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.host,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_4c895ac2b754e5559c1415b6546d672c58e29da6: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.protocol,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b: __fun,
        __cargo_web_snippet_62ef43cf95b12a9b5cdec1639439c972d6373280: function(r, t) {
            t = to_js(t),
                from_js(r, t.childNodes)
        },
        __cargo_web_snippet_6fcce0aae651e2d748e085ff1f800f87625ff8c8: function(r) {
            from_js(r, document)
        },
        __cargo_web_snippet_7ba9f102925446c90affc984f921f414615e07dd: function(r, t) {
            t = to_js(t),
                from_js(r, t.body)
        },
        __cargo_web_snippet_80d6d56760c65e49b7be8b6b01c1ea861b046bf0: __fun,
        __cargo_web_snippet_897ff2d0160606ea98961935acb125d1ddbf4688: __fun,
        __cargo_web_snippet_8c32019649bb581b1b742eeedfc410e2bedd56a6: function(r, t) {
            var _ = id_to_ref_map[r];
            serialize_array(t, _);
        },
        __cargo_web_snippet_a466a2ab96cd77e1a77dcdb39f4f031701c195fc: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.pathname,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_ab05f53189dacccf2d365ad26daa407d4f7abea9: function(r, t) {
            t = to_js(t),
                from_js(r, t.value)
        },
        __cargo_web_snippet_b06dde4acf09433b5190a4b001259fe5d4abcbc2: function(r, t) {
            t = to_js(t),
                from_js(r, t.success)
        },
        __cargo_web_snippet_b33a39de4ca954888e26fe9caa277138e808eeba: function(r, t) {
            t = to_js(t),
                from_js(r, t.length)
        },
        __cargo_web_snippet_cdf2859151791ce4cad80688b200564fb08a8613: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.href,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_e8ef87c41ded1c10f8de3c70dea31a053e19747c: function(r, t) {
            t = to_js(t),
                from_js(r, function() {
                    try {
                        return {
                            value: t.hostname,
                            success: !0
                        }
                    } catch (e) {
                        return {
                            error: e,
                            success: !1
                        }
                    }
                }())
        },
        __cargo_web_snippet_e9638d6405ab65f78daf4a5af9c9de14ecf1e2ec: __fun,
        __cargo_web_snippet_ff5103e6cc179d13b4c7a785bdce2708fd559fc0: function(r) {
            tmp = to_js(r)
        },
        __web_on_grow: __fun
    }
};

var wasmobject = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array(fs.readFileSync(wasmfilename))), importObject);
var wasmmemory = wasmobject.exports.memory;

var to_js = function (r) {
    var t = (new Uint8Array(wasmmemory.buffer))[r + 12];
    if (t !== 0){
        if(t === 1){
            return null;
        }else if(t === 2){
            return (new Int32Array(wasmmemory.buffer))[r / 4];
        }else if(t === 3){
            return (new Float64Array(wasmmemory.buffer))[r / 8];
        }else if(t === 4){
            var _ = (new Uint32Array(wasmmemory.buffer))[r / 4]
                , n = (new Uint32Array(wasmmemory.buffer))[(r + 4) / 4];
            return to_js_string(_, n)
        }else if(t === 5){
            return !1;
        }else if(t === 6){
            return !0;
        }else if(t === 7){
            console.log('返回数组。未实现')
        }else if(t === 8){
            console.log('返回对象。未实现')
        }else if(t === 9){
            return id_to_ref_map[(new Int32Array(wasmmemory.buffer))[r / 4]]
        }else {
            console.log('返回其他。未实现')
        }
    }

};

var to_js_string = function (r, _) {
    return (new Buffer.from((new Uint8Array(wasmmemory.buffer)).subarray(r, r + _))).toString()
};

var to_utf8_string = function (t, _) {
    var n = new Uint8Array(new Buffer.from(_, 'utf8'));
    var a = n.length;
    var c = wasmobject.exports.__web_malloc(a);
    var R = new Uint8Array(wasmmemory.buffer, c, a);
    R.set(n);
    (new Uint32Array(wasmmemory.buffer))[t / 4] = c;
    (new Uint32Array(wasmmemory.buffer))[(t + 4) / 4] = a;
};

var acquire_rust_reference = function (r) {
    var c = last_refid++;
    id_to_ref_map[c] = r;
    return c
};

var serialize_array = function (r, t) {
    var _ = t.length
        , n = wasmobject.exports.__web_malloc(16 * _);
    (new Uint8Array(wasmmemory.buffer))[r + 12] = 7;
    (new Uint32Array(wasmmemory.buffer))[r / 4] = n;
    (new Uint32Array(wasmmemory.buffer))[(r + 4) / 4] = _;
    for (var a = 0; a < _; ++a)
        from_js(n + 16 * a, t[a])
};

var from_js = function (r, t) {
    var _ = Object.prototype.toString.call(t);
    if ("[object String]" === _){
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 4;
        to_utf8_string(r, t);
    }
    else if ("[object Number]" === _)
        t === (0 | t) ? ((new Uint8Array(wasmmemory.buffer))[r + 12] = 2,
            (new Int32Array(wasmmemory.buffer))[r / 4] = t) : ((new Uint8Array(wasmmemory.buffer))[r + 12] = 3,
            (new Float64Array(wasmmemory.buffer))[r / 8] = t);
    else if (null === t)
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 1;
    else if (void 0 === t)
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 0;
    else if (!1 === t)
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 5;
    else if (!0 === t)
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 6;
    else if ("[object Symbol]" === _) {
        var n = register_raw_value(t);
        e.HEAPU8[r + 12] = 15,
            e.HEAP32[r / 4] = n
    } else {
        var a = acquire_rust_reference(t);
        (new Uint8Array(wasmmemory.buffer))[r + 12] = 9;
        (new Int32Array(wasmmemory.buffer))[r / 4] = a;
    }
};

var prepare_any_arg = function(r){
    var t = wasmobject.exports.__web_malloc(16);
    from_js(t, r);
    return t
};

var arge1 = '{"id":"[3,163,13,5887574]","device":"[\\"AUTO1716277899447614\\",\\"3fc2a589-9cb7-42bf-85c9-c2af590c2fad\\"]","ets":1627808068,"benchmark":"seacasdgyijfhofiuxoannn","time":60,"ts":1627808222759,"ua":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4580.0 Safari/537.36"}';
var arge2 = new Array();
arge2.push(2);
arge2.push(5);
arge2.push(1);
arge2.push(4);

var wasmr = prepare_any_arg(arge1);
var wasmt = prepare_any_arg(arge2);

wasmobject.exports.spyder.apply(null, [wasmr, wasmt]);
console.log(tmp)